package com.sss.shopping_mall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SssShoppingMallApplicationTests {

	@Test
	void contextLoads() {
	}

}
